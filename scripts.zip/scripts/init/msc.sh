sleep 5
cd /var/www/TIMIRIS/Automat/INIT/
pid_script=`ps -ef | grep "init_msc.php" | grep -v grep | awk '{print $2}'`
if [ "$pid_script"  = "" ]
 then
   `/usr/bin/php init_msc.php >> /tim_log/log_init/init_msc.log`
fi
