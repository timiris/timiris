sleep 5
cd /var/www/TIMIRIS/Automat/INIT/
pid_script=`ps -ef | grep "init_sms.php" | grep -v grep | awk '{print $2}'`
if [ "$pid_script"  = "" ]
 then
   `/usr/bin/php init_sms.php >> /tim_log/log_init/init_sms.log`
fi
