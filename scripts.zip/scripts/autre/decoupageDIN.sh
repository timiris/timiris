cd /var/www/TIMIRIS/Automat/DUMP_IN/
pid_script=`ps -ef | grep "decoupage.php" | grep -v grep | awk '{print $2}'`
if [ "$pid_script"  = "" ]
 then
   `/usr/bin/php decoupage.php >> /tim_log/log_autre/decoupageDIN.log`
fi
