dateJ=`date "+%Y%m%d"`
cd /var/www/TIMIRIS/Automat/
pid_script=`ps -ef | grep "ftpOCS.php" | grep -v grep | awk '{print $2}'`
if [ "$pid_script"  = "" ]
 then
   `/usr/bin/php ftpNewOCS.php >> /tim_log/log_autre/ftpOCS_$dateJ.log`
fi
