cd /tim_arch/sauvegarde/in/
for i in 20160*
do
if [ -d "$i" ]; then
   #echo -e "!!!!!!!!!!!!!!  Début journée $i   !!!!!!!!!!!!!!!!!!";
   rm -rf $i
fi
done
