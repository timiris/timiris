cd /var/www/TIMIRIS/Automat/
pid_script=`ps -ef | grep "ftpDIN.php" | grep -v grep | awk '{print $2}'`
if [ "$pid_script"  = "" ]
 then
   `/usr/bin/php ftpDIN.php >> /tim_log/log_autre/ftpDIN.log`
fi
