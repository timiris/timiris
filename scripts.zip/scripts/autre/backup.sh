#!/bin/bash
backupdir='/tim_arch/backup_bdd';
day=`date "+%Y%m%d"`;
//mkdir -p $backupdir/$day;

echo "PostgreSQL Backup for TIMIRIS";
echo "================================="
echo `date`;

printf "Backup de la bdd Timiris...";
/usr/bin/pg_dump -h localhost -U postgres timiris | gzip -c > $backupdir/timiris$day.sql.gz;
/bin/chmod 600 $backupdir/timiris$day.sql.gz;
printf "done\n";
echo `date`;
echo;
exit 0;
