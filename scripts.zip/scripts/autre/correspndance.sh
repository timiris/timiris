cd /var/www/TIMIRIS/Automat/
pid_script=`ps -ef | grep "maj_correspondance.php" | grep -v grep | awk '{print $2}'`
if [ "$pid_script"  = "" ]
 then
   `/usr/bin/php maj_correspondance.php >> /tim_log/log_autre/correspndance.log`
fi
