#!/bin/sh
# constantes
HOST=192.168.3.113
LOGIN=cheibani
PASSWORD=123456
PORT=21
cd /tim_arch/dump/fidelity/
# le transfert lui meme
ftp  -n $HOST < quote USER $LOGIN
quote PASS $PASSWORD
cd TIMIRIS
bin
mput *.txt
quit
END_SCRIPT
for i in *.txt
do
gzip $i
done
