#!/bin/sh
dateJour=`date --date="1 days ago" "+%Y%m%d"`
#echo $dateMois;
cd /tim_arch/sauvegarde/in
if [ -d "$dateJour" ]; then
   cd $dateJour
   cat vou* | awk -F"|" '{if($280==54)print $12"|"$247}'  >> /tim_arch/sauvegarde/in/Mechili_report/$dateJour
fi
