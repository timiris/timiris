sleep 2
n=1
mv /tim_DATA/cdrs/error/msc/b* /tim_DATA/cdrs/chargement/msc/
pid_script=`ps -ef | grep "ftpOCS.php" | grep -v grep | awk '{print $2}'`

while [ $n -lt 200 -a  "$pid_script" != "" ]
do
        pid_script=`ps -ef | grep "ftpOCS.php" | grep -v grep | awk '{print $2}'`
        n=$(( n+1 ))     # increments $n
        sleep 1
done

if [ $n -eq 200 ]
  then
        exit
fi

cd /var/www/TIMIRIS/Automat/
pid_script=`ps -ef | grep "ftpNewOCS_rejected.php" | grep -v grep | awk '{print $2}'`
if [ "$pid_script"  = "" ]
 then
   `/usr/bin/php ftpNewOCS_rejected.php >> /tim_log/log_autre/ftpOCS_rejected.log`
fi
