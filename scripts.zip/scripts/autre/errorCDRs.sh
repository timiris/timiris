mv /tim_DATA/cdrs/error/in/rec*.unl /tim_DATA/cdrs/chargement/in/rec/
mv /tim_DATA/cdrs/error/in/sms*.unl /tim_DATA/cdrs/chargement/in/sms/
mv /tim_DATA/cdrs/error/in/data*.unl /tim_DATA/cdrs/chargement/in/data/
mv /tim_DATA/cdrs/error/in/mgr*.unl /tim_DATA/cdrs/chargement/in/mgr/
mv /tim_DATA/cdrs/error/in/vou*.unl /tim_DATA/cdrs/chargement/in/vou/
mv /tim_DATA/cdrs/error/in/mon*.unl /tim_DATA/cdrs/chargement/in/mon/
mv /tim_DATA/cdrs/error/in/clr*.unl /tim_DATA/cdrs/chargement/in/clr/
