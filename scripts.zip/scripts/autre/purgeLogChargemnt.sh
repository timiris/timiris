#!/bin/sh
dateJour=`date --date="10 days ago" "+%Y%m%d"`
rep_log="/tim_log/log_chargement"
rm -f $rep_log/data/import_data_$dateJour.log
rm -f $rep_log/rec/import_rec_$dateJour.log
rm -f $rep_log/sms/import_sms_$dateJour.log
rm -f $rep_log/vou/import_vou_$dateJour.log
rm -f $rep_log/mgr/import_mgr_$dateJour.log
rm -f $rep_log/msc/import_msc_$dateJour.log
rm -f $rep_log/clr/import_clr_$dateJour.log
rm -f $rep_log/mon/import_mon_$dateJour.log
rm -f $rep_log/din/import_dump_in_$dateJour.log

rm -f /tim_log/log_autre/ftpOCS_$dateJour.log

rm -f /tim_arch/backup_bdd/timiris$dateJour.sql.gz
