cd /var/www/TIMIRIS/Automat/Supervision
`/usr/bin/php verif_correspondance.php  >> /tim_log/log_autre/verif_correspondance.log`
