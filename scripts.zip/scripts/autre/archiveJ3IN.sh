#!/bin/sh
dateJour=`date --date="3 days ago" "+%Y%m%d"`
#echo $dateMois;
cd /tim_arch/sauvegarde/in
if [ -d "$dateJour" ]; then
   echo -e "############ Debut archivage des cdrs IN  de la journee : "$dateJour" ###############";
   tar -czf $dateJour.tar.gz $dateJour
   rm -rf $dateJour
   echo -e "!!!!!!!!!!!!!!  Fin archivage   !!!!!!!!!!!!!!!!!!";
fi

cd /tim_arch/sauvegarde/msc
if [ -d "$dateJour" ]; then
   echo -e "############ Debut archivage des cdrs MSC de la journee : "$dateJour" ###############";
   tar -czf $dateJour.tar.gz $dateJour
   rm -rf $dateJour
   echo -e "!!!!!!!!!!!!!!  Fin archivage   !!!!!!!!!!!!!!!!!!";
fi


dateJour=`date --date="7 days ago" "+%Y%m%d"`
cd /tim_arch/dump/in/
for file in  $dateJour*.gz
do
 if [ -f $file ]; then
   echo -e "Suppression du $file ###########";
   rm -f $file 
 fi
done

for i in 201*.list
do
  if [ -f "$i" ]; then
    echo -e $i;
    tar -czf $i.tar.gz $i
    rm -f $i
  fi
done
