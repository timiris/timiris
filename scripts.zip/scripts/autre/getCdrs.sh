#!/bin/sh
# constantes
cbp1=/rbidata/rbi/RBIRecord/cdr/cbp1/normal/bak/
cbp2=/rbidata/rbi/RBIRecord/cdr/cbp2/normal/bak/
HOST=10.86.3.67
LOGIN=ocscdr
PASSWORD=bill
PORT=21

dateJour=20170101
ftp -i -n $HOST $PORT << END_SCRIPT
quote USER $LOGIN
quote PASS $PASSWORD
bin
cd $cbp1$dateJour
lcd /tim_log/cdrs/chargement/in/data/
mget data*.unl
lcd /tim_log/cdrs/chargement/in/rec/
mget rec*.unl
lcd /tim_log/cdrs/chargement/in/mgr/
mget mgr*.unl
lcd /tim_log/cdrs/chargement/in/sms/
mget sms*.unl
cd /tim_log/cdrs/chargement/in/vou/
mget vou*.unl

cd $cbp2$dateJour
lcd /tim_log/cdrs/chargement/in/data/
mget data*.unl
lcd /tim_log/cdrs/chargement/in/rec/
mget rec*.unl
lcd /tim_log/cdrs/chargement/in/mgr/
mget mgr*.unl
lcd /tim_log/cdrs/chargement/in/sms/
mget sms*.unl
cd /tim_log/cdrs/chargement/in/vou/
mget vou*.unl
quit

dateJour = 20170102
ftp -i -n $HOST $PORT << END_SCRIPT
quote USER $LOGIN
quote PASS $PASSWORD
bin
cd $cbp1$dateJour
lcd /tim_log/cdrs/chargement/in/data/
mget data*.unl
lcd /tim_log/cdrs/chargement/in/rec/
mget rec*.unl
lcd /tim_log/cdrs/chargement/in/mgr/
mget mgr*.unl
lcd /tim_log/cdrs/chargement/in/sms/
mget sms*.unl
cd /tim_log/cdrs/chargement/in/vou/
mget vou*.unl

cd $cbp2$dateJour
lcd /tim_log/cdrs/chargement/in/data/
mget data*.unl
lcd /tim_log/cdrs/chargement/in/rec/
mget rec*.unl
lcd /tim_log/cdrs/chargement/in/mgr/
mget mgr*.unl
lcd /tim_log/cdrs/chargement/in/sms/
mget sms*.unl
cd /tim_log/cdrs/chargement/in/vou/
mget vou*.unl
quit

dateJour = 20170103
ftp -i -n $HOST $PORT << END_SCRIPT
quote USER $LOGIN
quote PASS $PASSWORD
bin
cd $cbp1$dateJour
lcd /tim_log/cdrs/chargement/in/data/
mget data*.unl
lcd /tim_log/cdrs/chargement/in/rec/
mget rec*.unl
lcd /tim_log/cdrs/chargement/in/mgr/
mget mgr*.unl
lcd /tim_log/cdrs/chargement/in/sms/
mget sms*.unl
cd /tim_log/cdrs/chargement/in/vou/
mget vou*.unl

cd $cbp2$dateJour
lcd /tim_log/cdrs/chargement/in/data/
mget data*.unl
lcd /tim_log/cdrs/chargement/in/rec/
mget rec*.unl
lcd /tim_log/cdrs/chargement/in/mgr/
mget mgr*.unl
lcd /tim_log/cdrs/chargement/in/sms/
mget sms*.unl
cd /tim_log/cdrs/chargement/in/vou/
mget vou*.unl
quit

dateJour = 20170104
ftp -i -n $HOST $PORT << END_SCRIPT
quote USER $LOGIN
quote PASS $PASSWORD
bin
cd $cbp1$dateJour
lcd /tim_log/cdrs/chargement/in/data/
mget data*.unl
lcd /tim_log/cdrs/chargement/in/rec/
mget rec*.unl
lcd /tim_log/cdrs/chargement/in/mgr/
mget mgr*.unl
lcd /tim_log/cdrs/chargement/in/sms/
mget sms*.unl
cd /tim_log/cdrs/chargement/in/vou/
mget vou*.unl

cd $cbp2$dateJour
lcd /tim_log/cdrs/chargement/in/data/
mget data*.unl
lcd /tim_log/cdrs/chargement/in/rec/
mget rec*.unl
lcd /tim_log/cdrs/chargement/in/mgr/
mget mgr*.unl
lcd /tim_log/cdrs/chargement/in/sms/
mget sms*.unl
cd /tim_log/cdrs/chargement/in/vou/
mget vou*.unl
quit

dateJour = 20170105
ftp -i -n $HOST $PORT << END_SCRIPT
quote USER $LOGIN
quote PASS $PASSWORD
bin
cd $cbp1$dateJour
lcd /tim_log/cdrs/chargement/in/data/
mget data*.unl
lcd /tim_log/cdrs/chargement/in/rec/
mget rec*.unl
lcd /tim_log/cdrs/chargement/in/mgr/
mget mgr*.unl
lcd /tim_log/cdrs/chargement/in/sms/
mget sms*.unl
cd /tim_log/cdrs/chargement/in/vou/
mget vou*.unl

cd $cbp2$dateJour
lcd /tim_log/cdrs/chargement/in/data/
mget data*.unl
lcd /tim_log/cdrs/chargement/in/rec/
mget rec*.unl
lcd /tim_log/cdrs/chargement/in/mgr/
mget mgr*.unl
lcd /tim_log/cdrs/chargement/in/sms/
mget sms*.unl
cd /tim_log/cdrs/chargement/in/vou/
mget vou*.unl
quit

dateJour = 20170107
ftp -i -n $HOST $PORT << END_SCRIPT
quote USER $LOGIN
quote PASS $PASSWORD
bin
cd $cbp1$dateJour
lcd /tim_log/cdrs/chargement/in/data/
mget data*.unl
lcd /tim_log/cdrs/chargement/in/rec/
mget rec*.unl
lcd /tim_log/cdrs/chargement/in/mgr/
mget mgr*.unl
lcd /tim_log/cdrs/chargement/in/sms/
mget sms*.unl
cd /tim_log/cdrs/chargement/in/vou/
mget vou*.unl

cd $cbp2$dateJour
lcd /tim_log/cdrs/chargement/in/data/
mget data*.unl
lcd /tim_log/cdrs/chargement/in/rec/
mget rec*.unl
lcd /tim_log/cdrs/chargement/in/mgr/
mget mgr*.unl
lcd /tim_log/cdrs/chargement/in/sms/
mget sms*.unl
cd /tim_log/cdrs/chargement/in/vou/
mget vou*.unl
quit

dateJour = 20170108
ftp -i -n $HOST $PORT << END_SCRIPT
quote USER $LOGIN
quote PASS $PASSWORD
bin
cd $cbp1$dateJour
lcd /tim_log/cdrs/chargement/in/data/
mget data*.unl
lcd /tim_log/cdrs/chargement/in/rec/
mget rec*.unl
lcd /tim_log/cdrs/chargement/in/mgr/
mget mgr*.unl
lcd /tim_log/cdrs/chargement/in/sms/
mget sms*.unl
cd /tim_log/cdrs/chargement/in/vou/
mget vou*.unl

cd $cbp2$dateJour
lcd /tim_log/cdrs/chargement/in/data/
mget data*.unl
lcd /tim_log/cdrs/chargement/in/rec/
mget rec*.unl
lcd /tim_log/cdrs/chargement/in/mgr/
mget mgr*.unl
lcd /tim_log/cdrs/chargement/in/sms/
mget sms*.unl
cd /tim_log/cdrs/chargement/in/vou/
mget vou*.unl
quit

dateJour = 20170109
ftp -i -n $HOST $PORT << END_SCRIPT
quote USER $LOGIN
quote PASS $PASSWORD
bin
cd $cbp1$dateJour
lcd /tim_log/cdrs/chargement/in/data/
mget data*.unl
lcd /tim_log/cdrs/chargement/in/rec/
mget rec*.unl
lcd /tim_log/cdrs/chargement/in/mgr/
mget mgr*.unl
lcd /tim_log/cdrs/chargement/in/sms/
mget sms*.unl
cd /tim_log/cdrs/chargement/in/vou/
mget vou*.unl

cd $cbp2$dateJour
lcd /tim_log/cdrs/chargement/in/data/
mget data*.unl
lcd /tim_log/cdrs/chargement/in/rec/
mget rec*.unl
lcd /tim_log/cdrs/chargement/in/mgr/
mget mgr*.unl
lcd /tim_log/cdrs/chargement/in/sms/
mget sms*.unl
cd /tim_log/cdrs/chargement/in/vou/
mget vou*.unl
quit

dateJour = 20170110
ftp -i -n $HOST $PORT << END_SCRIPT
quote USER $LOGIN
quote PASS $PASSWORD
bin
cd $cbp1$dateJour
lcd /tim_log/cdrs/chargement/in/data/
mget data*.unl
lcd /tim_log/cdrs/chargement/in/rec/
mget rec*.unl
lcd /tim_log/cdrs/chargement/in/mgr/
mget mgr*.unl
lcd /tim_log/cdrs/chargement/in/sms/
mget sms*.unl
cd /tim_log/cdrs/chargement/in/vou/
mget vou*.unl

cd $cbp2$dateJour
lcd /tim_log/cdrs/chargement/in/data/
mget data*.unl
lcd /tim_log/cdrs/chargement/in/rec/
mget rec*.unl
lcd /tim_log/cdrs/chargement/in/mgr/
mget mgr*.unl
lcd /tim_log/cdrs/chargement/in/sms/
mget sms*.unl
cd /tim_log/cdrs/chargement/in/vou/
mget vou*.unl
quit

dateJour = 20170111
ftp -i -n $HOST $PORT << END_SCRIPT
quote USER $LOGIN
quote PASS $PASSWORD
bin
cd $cbp1$dateJour
lcd /tim_log/cdrs/chargement/in/data/
mget data*.unl
lcd /tim_log/cdrs/chargement/in/rec/
mget rec*.unl
lcd /tim_log/cdrs/chargement/in/mgr/
mget mgr*.unl
lcd /tim_log/cdrs/chargement/in/sms/
mget sms*.unl
cd /tim_log/cdrs/chargement/in/vou/
mget vou*.unl

cd $cbp2$dateJour
lcd /tim_log/cdrs/chargement/in/data/
mget data*.unl
lcd /tim_log/cdrs/chargement/in/rec/
mget rec*.unl
lcd /tim_log/cdrs/chargement/in/mgr/
mget mgr*.unl
lcd /tim_log/cdrs/chargement/in/sms/
mget sms*.unl
cd /tim_log/cdrs/chargement/in/vou/
mget vou*.unl
quit

dateJour = 20170112
ftp -i -n $HOST $PORT << END_SCRIPT
quote USER $LOGIN
quote PASS $PASSWORD
bin
cd $cbp1$dateJour
lcd /tim_log/cdrs/chargement/in/data/
mget data*.unl
lcd /tim_log/cdrs/chargement/in/rec/
mget rec*.unl
lcd /tim_log/cdrs/chargement/in/mgr/
mget mgr*.unl
lcd /tim_log/cdrs/chargement/in/sms/
mget sms*.unl
cd /tim_log/cdrs/chargement/in/vou/
mget vou*.unl

cd $cbp2$dateJour
lcd /tim_log/cdrs/chargement/in/data/
mget data*.unl
lcd /tim_log/cdrs/chargement/in/rec/
mget rec*.unl
lcd /tim_log/cdrs/chargement/in/mgr/
mget mgr*.unl
lcd /tim_log/cdrs/chargement/in/sms/
mget sms*.unl
cd /tim_log/cdrs/chargement/in/vou/
mget vou*.unl
quit

dateJour = 20170113
ftp -i -n $HOST $PORT << END_SCRIPT
quote USER $LOGIN
quote PASS $PASSWORD
bin
cd $cbp1$dateJour
lcd /tim_log/cdrs/chargement/in/data/
mget data*.unl
lcd /tim_log/cdrs/chargement/in/rec/
mget rec*.unl
lcd /tim_log/cdrs/chargement/in/mgr/
mget mgr*.unl
lcd /tim_log/cdrs/chargement/in/sms/
mget sms*.unl
cd /tim_log/cdrs/chargement/in/vou/
mget vou*.unl

cd $cbp2$dateJour
lcd /tim_log/cdrs/chargement/in/data/
mget data*.unl
lcd /tim_log/cdrs/chargement/in/rec/
mget rec*.unl
lcd /tim_log/cdrs/chargement/in/mgr/
mget mgr*.unl
lcd /tim_log/cdrs/chargement/in/sms/
mget sms*.unl
cd /tim_log/cdrs/chargement/in/vou/
mget vou*.unl
quit

dateJour = 20170114
ftp -i -n $HOST $PORT << END_SCRIPT
quote USER $LOGIN
quote PASS $PASSWORD
bin
cd $cbp1$dateJour
lcd /tim_log/cdrs/chargement/in/data/
mget data*.unl
lcd /tim_log/cdrs/chargement/in/rec/
mget rec*.unl
lcd /tim_log/cdrs/chargement/in/mgr/
mget mgr*.unl
lcd /tim_log/cdrs/chargement/in/sms/
mget sms*.unl
cd /tim_log/cdrs/chargement/in/vou/
mget vou*.unl

cd $cbp2$dateJour
lcd /tim_log/cdrs/chargement/in/data/
mget data*.unl
lcd /tim_log/cdrs/chargement/in/rec/
mget rec*.unl
lcd /tim_log/cdrs/chargement/in/mgr/
mget mgr*.unl
lcd /tim_log/cdrs/chargement/in/sms/
mget sms*.unl
cd /tim_log/cdrs/chargement/in/vou/
mget vou*.unl
quit

dateJour = 20170115
ftp -i -n $HOST $PORT << END_SCRIPT
quote USER $LOGIN
quote PASS $PASSWORD
bin
cd $cbp1$dateJour
lcd /tim_log/cdrs/chargement/in/data/
mget data*.unl
lcd /tim_log/cdrs/chargement/in/rec/
mget rec*.unl
lcd /tim_log/cdrs/chargement/in/mgr/
mget mgr*.unl
lcd /tim_log/cdrs/chargement/in/sms/
mget sms*.unl
cd /tim_log/cdrs/chargement/in/vou/
mget vou*.unl

cd $cbp2$dateJour
lcd /tim_log/cdrs/chargement/in/data/
mget data*.unl
lcd /tim_log/cdrs/chargement/in/rec/
mget rec*.unl
lcd /tim_log/cdrs/chargement/in/mgr/
mget mgr*.unl
lcd /tim_log/cdrs/chargement/in/sms/
mget sms*.unl
cd /tim_log/cdrs/chargement/in/vou/
mget vou*.unl
quit

