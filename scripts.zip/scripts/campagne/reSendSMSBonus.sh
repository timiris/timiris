cd /var/www/TIMIRIS/campagne/bonus/
pid_script=`ps -ef | grep "relance_sms_bonus.php" | grep -v grep | awk '{print $2}'`
if [ "$pid_script"  = "" ]
 then
   `/usr/bin/php relance_sms_bonus.php >> /tim_log/log_campagne/bonus/reSendSMSBonus.log`
fi
