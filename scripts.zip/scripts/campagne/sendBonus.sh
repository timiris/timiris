cd /var/www/TIMIRIS/campagne/bonus/
dateJ=`date "+%Y%m%d"`
pid_script=`ps -ef | grep "attribuerBonus.php" | grep -v grep | awk '{print $2}'`
if [ "$pid_script"  = "" ]
 then
   `/usr/bin/php attribuerBonus.php >> /tim_log/log_campagne/bonus/sendBonus_$dateJ.log`
fi
