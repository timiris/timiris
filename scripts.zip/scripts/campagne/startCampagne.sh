cd /var/www/TIMIRIS/campagne/
pid_script=`ps -ef | grep "start_campagne.php" | grep -v grep | awk '{print $2}'`
if [ "$pid_script"  = "" ]
 then
   `/usr/bin/php start_campagne.php >> /tim_log/log_campagne/start_campagne.log`
fi
