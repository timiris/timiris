cd /var/www/TIMIRIS/campagne/
pid_script=`ps -ef | grep "campagne_cumul.php" | grep -v grep | awk '{print $2}'`
if [ "$pid_script"  = "" ]
 then
   `/usr/bin/php-cgi -f campagne_cumul.php periode=j >> /tim_log/log_campagne/campagne_cumul.log`
fi
