cd /var/www/TIMIRIS/campagne/
pid_script=`ps -ef | grep "sms_teasing.php" | grep -v grep | awk '{print $2}'`
if [ "$pid_script"  = "" ]
 then
   `/usr/bin/php sms_teasing.php >> /tim_log/log_campagne/sms_teasing.log`
fi
