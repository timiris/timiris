sleep 2
n=1
pid_script=`ps -ef | grep "ftpOCS.php" | grep -v grep | awk '{print $2}'`

while [ $n -lt 50 -a  "$pid_script" != "" ]
do
        pid_script=`ps -ef | grep "ftpOCS.php" | grep -v grep | awk '{print $2}'`
        n=$(( n+1 ))     # increments $n
        sleep 1
done
sleep 2
dateJ=`date "+%Y%m%d"`
pid_script=`ps -ef | grep "init_rec.php" | grep -v grep | awk '{print $2}'`
if [ "$pid_script"  = "" ]
 then
	cd /var/www/TIMIRIS/Automat/REC/
	pid_script=`ps -ef | grep "import_rec.php" | grep -v grep | awk '{print $2}'`
	if [ "$pid_script"  = "" ]
	 then
	   `/usr/bin/php import_rec.php >> /tim_log/log_chargement/rec/import_rec_$dateJ.log`
	fi
fi
