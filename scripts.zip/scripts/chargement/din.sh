dateJ=`date "+%Y%m%d"`
cd /var/www/TIMIRIS/Automat/DUMP_IN/
pid_script=`ps -ef | grep "import_dump_in.php" | grep -v grep | awk '{print $2}'`
if [ "$pid_script"  = "" ]
  then
	`/usr/bin/php import_dump_in.php >> /tim_log/log_chargement/din/import_dump_in_$dateJ.log`
fi
