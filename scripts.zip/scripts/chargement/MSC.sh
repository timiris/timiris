dateJ=`date "+%Y%m%d"`
pid_script=`ps -ef | grep "init_msc.php" | grep -v grep | awk '{print $2}'`
if [ "$pid_script"  = "" ]
 then
	cd /var/www/TIMIRIS/Automat/MSC/
	pid_script=`ps -ef | grep "import_msc.php" | grep -v grep | awk '{print $2}'`
	if [ "$pid_script"  = "" ]
	 then
	   `/usr/bin/php import_msc.php >> /tim_log/log_chargement/msc/import_msc_$dateJ.log`
	fi
fi
