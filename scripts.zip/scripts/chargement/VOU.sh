sleep 2
n=1
pid_script=`ps -ef | grep "ftpOCS.php" | grep -v grep | awk '{print $2}'`

while [ $n -lt 50 -a  "$pid_script" != "" ]
do
        pid_script=`ps -ef | grep "ftpOCS.php" | grep -v grep | awk '{print $2}'`
        n=$(( n+1 ))     # increments $n
        sleep 1
done
sleep 2
dateJ=`date "+%Y%m%d"`
pid_script=`ps -ef | grep "init_vou.php" | grep -v grep | awk '{print $2}'`
if [ "$pid_script"  = "" ]
 then
	cd /var/www/TIMIRIS/Automat/VOU/
	pid_script=`ps -ef | grep "import_vou.php" | grep -v grep | awk '{print $2}'`
	if [ "$pid_script"  = "" ]
	 then
	   `/usr/bin/php import_vou.php >> /tim_log/log_chargement/vou/import_vou_$dateJ.log`
	fi
fi
