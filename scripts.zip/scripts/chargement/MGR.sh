sleep 2
n=1
pid_script=`ps -ef | grep "ftpOCS.php" | grep -v grep | awk '{print $2}'`

while [ $n -lt 50 -a  "$pid_script" != "" ]
do
        pid_script=`ps -ef | grep "ftpOCS.php" | grep -v grep | awk '{print $2}'`
        n=$(( n+1 ))     # increments $n
        sleep 1
done
sleep 2
dateJ=`date "+%Y%m%d"`
pid_script=`ps -ef | grep "init_mgr.php" | grep -v grep | awk '{print $2}'`
if [ "$pid_script"  = "" ]
 then
	cd /var/www/TIMIRIS/Automat/MGR/
	pid_script=`ps -ef | grep "import_mgr" | grep -v grep | awk '{print $2}'`
	if [ "$pid_script"  = "" ]
 	 then
   		`/usr/bin/php import_mgr.php >> /tim_log/log_chargement/mgr/import_mgr_$dateJ.log`
                cd /var/www/TIMIRIS/Automat/MON/
   		`/usr/bin/php import_mgr_mon.php >> /tim_log/log_chargement/mon/import_mon_$dateJ.log`
                cd /var/www/TIMIRIS/Automat/CLR/
   		`/usr/bin/php import_mgr_clr.php >> /tim_log/log_chargement/clr/import_clr_$dateJ.log`
	fi
fi
