cd /var/www/TIMIRIS/Automat/VOU/
pid_script=`ps -ef | grep "import_vou.php" | grep -v grep | awk '{print $2}'`
if [ "$pid_script"  = "" ]
 then
   `/usr/bin/php import_vou.php >> /data/log/log_execution/import_vou.log`
fi
