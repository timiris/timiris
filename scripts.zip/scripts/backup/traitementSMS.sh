cd /var/www/TIMIRIS/Automat/SMS/
pid_script=`ps -ef | grep "import_sms.php" | grep -v grep | awk '{print $2}'`
if [ "$pid_script"  = "" ]
 then
   `/usr/bin/php import_sms.php >> /data/log/log_execution/import_sms.log`
fi
