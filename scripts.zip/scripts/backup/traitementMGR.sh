cd /var/www/TIMIRIS/Automat/MGR/
pid_script=`ps -ef | grep "import_mgr.php" | grep -v grep | awk '{print $2}'`
if [ "$pid_script"  = "" ]
 then
   `/usr/bin/php import_mgr.php >> /data/log/log_execution/import_mgr.log`
fi
