cd /var/www/TIMIRIS/Automat/DATA/
pid_script=`ps -ef | grep "import_data.php" | grep -v grep | awk '{print $2}'`
if [ "$pid_script"  = "" ]
 then
   `/usr/bin/php import_data.php >> /data/log/log_execution/import_data.log`
fi
