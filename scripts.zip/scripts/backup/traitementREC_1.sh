cd /var/www/TIMIRIS/Automat/REC_1/
pid_script=`ps -ef | grep "import_rec_1.php" | grep -v grep | awk '{print $2}'`
if [ "$pid_script"  = "" ]
 then
   `/usr/bin/php import_rec_1.php >> /data/log_execution/import_rec_1.log`
fi
