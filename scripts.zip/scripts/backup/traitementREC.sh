cd /var/www/TIMIRIS/Automat/REC/
pid_script=`ps -ef | grep "import_rec.php" | grep -v grep | awk '{print $2}'`
if [ "$pid_script"  = "" ]
 then
   `/usr/bin/php import_rec.php >> /data/log/log_execution/import_rec.log`
fi
