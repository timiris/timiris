cd /var/www/TIMIRIS/Automat/MSC/
pid_script=`ps -ef | grep "import_msc.php" | grep -v grep | awk '{print $2}'`
if [ "$pid_script"  = "" ]
 then
   `/usr/bin/php import_msc.php >> /data/log/log_execution/import_msc.log`
fi
