cd /var/www/TIMIRIS/Automat/fidelity/
pid_script=`ps -ef | grep "ftpFidelity.php" | grep -v grep | awk '{print $2}'`
if [ "$pid_script"  = "" ]
 then
   `/usr/bin/php ftpFidelity.php >> /tim_log/log_autre/fidelity_ftp.log`
fi
