cd /var/www/TIMIRIS/Automat/fidelity/
pid_script=`ps -ef | grep "dumpFidelity.php" | grep -v grep | awk '{print $2}'`
if [ "$pid_script"  = "" ]
 then
   `/usr/bin/php dumpFidelity.php >> /tim_log/log_autre/fidelity.log`
fi
